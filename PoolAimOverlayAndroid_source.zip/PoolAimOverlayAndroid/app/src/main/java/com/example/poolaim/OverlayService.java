package com.example.poolaim;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    public static final String ACTION_START = "com.example.poolaim.START";
    public static final String ACTION_STOP = "com.example.poolaim.STOP";
    public static final String ACTION_RESET = "com.example.poolaim.RESET";
    private static final String CHANNEL = "pool_aim_overlay";
    private WindowManager windowManager;
    private WindowManager.LayoutParams canvasParams, toolbarParams;
    private OverlayView aimView;
    private LinearLayout toolbar;
    private TextView editButton, playButton, eyeButton;
    private boolean editing = true;
    private boolean hidden = false;
    private SharedPreferences preferences;
    private SharedPreferences.OnSharedPreferenceChangeListener listener;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Прицел поверх игры", NotificationManager.IMPORTANCE_LOW));
        Intent stopIntent = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Pool Aim Overlay работает")
                .setContentText("Нажми ✎ для настройки · ▶ для игры")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", pi)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(44, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(44, notification);
        preferences = getSharedPreferences("overlay", MODE_PRIVATE);
        listener = (p, key) -> { if (aimView != null) aimView.invalidate(); };
        preferences.registerOnSharedPreferenceChangeListener(listener);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_RESET.equals(action)) {
            if (aimView != null) aimView.resetPositions();
            else stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (aimView == null) makeWindows();
        return START_NOT_STICKY;
    }

    private void makeWindows() {
        aimView = new OverlayView(this, preferences);
        canvasParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        canvasParams.gravity = Gravity.TOP | Gravity.START;
        canvasParams.alpha = 1.0f;
        windowManager.addView(aimView, canvasParams);

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(dp(5), dp(4), dp(5), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEF172332); bg.setCornerRadius(dp(16));
        toolbar.setBackground(bg);
        TextView drag = toolButton("≡");
        toolbar.addView(drag);
        editButton = toolButton("✎"); toolbar.addView(editButton);
        playButton = toolButton("▶"); toolbar.addView(playButton);
        eyeButton = toolButton("◉"); toolbar.addView(eyeButton);
        TextView stopButton = toolButton("×"); toolbar.addView(stopButton);
        drag.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int originX, originY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        originX = toolbarParams.x; originY = toolbarParams.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        toolbarParams.x = Math.max(0, originX + (int)(event.getRawX() - downX));
                        toolbarParams.y = Math.max(0, originY + (int)(event.getRawY() - downY));
                        if (toolbar != null) windowManager.updateViewLayout(toolbar, toolbarParams);
                        return true;
                    case MotionEvent.ACTION_UP: return true;
                    default: return true;
                }
            }
        });
        editButton.setOnClickListener(v -> setEditing(true));
        playButton.setOnClickListener(v -> setEditing(false));
        eyeButton.setOnClickListener(v -> {
            hidden = !hidden;
            aimView.setVisibility(hidden ? View.INVISIBLE : View.VISIBLE);
            eyeButton.setText(hidden ? "◎" : "◉");
        });
        stopButton.setOnClickListener(v -> stopSelf());
        toolbarParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        toolbarParams.gravity = Gravity.TOP | Gravity.START;
        toolbarParams.x = dp(12); toolbarParams.y = dp(38);
        windowManager.addView(toolbar, toolbarParams);
        setEditing(true);
    }

    private TextView toolButton(String caption) {
        TextView b = new TextView(this); b.setText(caption); b.setTextColor(Color.WHITE);
        b.setTextSize(20); b.setGravity(Gravity.CENTER);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(43), dp(39)));
        return b;
    }

    private void setEditing(boolean value) {
        if (aimView == null) return;
        editing = value;
        // Android 12+ can reject touches through untrusted overlays whose opacity exceeds 0.8.
        // The transparent drawing window must become non-touchable AND use alpha <= 0.8.
        if (editing) {
            canvasParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            canvasParams.alpha = 1f;
        } else {
            aimView.savePositions();
            canvasParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            canvasParams.alpha = 0.75f;
        }
        windowManager.updateViewLayout(aimView, canvasParams);
        editButton.setTextColor(editing ? 0xFF38E6B0 : Color.WHITE);
        playButton.setTextColor(editing ? Color.WHITE : 0xFF38E6B0);
        aimView.setEditing(editing);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (aimView != null) aimView.requestLayout();
    }
    @Override public void onDestroy() {
        if (preferences != null && listener != null) preferences.unregisterOnSharedPreferenceChangeListener(listener);
        if (aimView != null) {
            aimView.savePositions();
            try { windowManager.removeView(aimView); } catch (Exception ignored) {}
            aimView = null;
        }
        if (toolbar != null) {
            try { windowManager.removeView(toolbar); } catch (Exception ignored) {}
            toolbar = null;
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
}
