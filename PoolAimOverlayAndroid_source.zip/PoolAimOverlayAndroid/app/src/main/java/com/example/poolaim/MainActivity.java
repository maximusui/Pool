package com.example.poolaim;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView permissionStatus;
    private final int[] colors = {Color.WHITE, 0xFF38E6B0, 0xFF00DCFF, 0xFFFFDB70, 0xFFFF63A5};
    private final String[] colorNames = {"Белый", "Зелёный", "Голубой", "Жёлтый", "Розовый"};
    private Button colorButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("overlay", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFF10151F);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(24));
        scroll.addView(root);
        root.addView(text("POOL AIM", 31, 0xFF38E6B0, true));
        root.addView(text("Плавающий прицел для бильярда", 17, Color.WHITE, true));
        TextView intro = text("Прозрачные линии поверх игры. Без root, без доступа к экрану и без изменения игры. Все маркеры выставляются вручную.", 14, 0xFFC6D0DF, false);
        intro.setPadding(0, dp(14), 0, dp(18)); root.addView(intro);
        permissionStatus = text("", 14, 0xFFB6EECE, true); root.addView(permissionStatus);
        root.addView(button("1 · Разрешить поверх других приложений", () -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        root.addView(button("2 · Запустить прицел", () -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                return;
            }
            Intent i = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_START);
            try { startForegroundService(i); } catch (Exception e) { permissionStatus.setText("Не удалось запустить: " + e.getMessage()); }
        }));
        root.addView(button("Остановить прицел", () -> startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_STOP))));

        TextView header = text("НАСТРОЙКИ", 19, Color.WHITE, true);
        header.setPadding(0, dp(24), 0, dp(6)); root.addView(header);
        addCheck(root, "Прямая линия", "direct", true);
        addCheck(root, "Линии к шести лузам", "pockets", true);
        addCheck(root, "Отражение от одного борта", "bank", true);
        addCheck(root, "Отражение от двух бортов", "doublebank", true);
        root.addView(text("Толщина линий", 15, 0xFFE7EAF2, false));
        SeekBar thickness = new SeekBar(this); thickness.setMax(11);
        thickness.setProgress(prefs.getInt("thickness", 3) - 1);
        thickness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) prefs.edit().putInt("thickness", p + 1).apply(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        }); root.addView(thickness);
        colorButton = button("", () -> {
            int n = (prefs.getInt("colorIndex", 0) + 1) % colors.length;
            prefs.edit().putInt("colorIndex", n).apply();
            updateColorText();
        }); root.addView(colorButton); updateColorText();
        root.addView(button("Сбросить положение маркеров", () -> {
            prefs.edit().remove("port_table").remove("port_ballA").remove("port_ballB").remove("port_guide")
                    .remove("land_table").remove("land_ballA").remove("land_ballB").remove("land_guide").apply();
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_RESET));
        }));

        TextView help = text("КАК ИСПОЛЬЗОВАТЬ\n\n1. Открой 8 Ball Pool и поверни телефон горизонтально.\n2. Нажми ✎ на плавающей панели. Передвинь границы стола, два маркера и центральную точку.\n3. Нажми ▶ — линии останутся, а касания будут проходить в игру.\n4. Снова ✎ — чтобы поправить положение. Кнопка ◉ скрывает/показывает линии, × выключает приложение.\n\nПрицел геометрический, без распознавания шаров и учёта силы удара, вращения или столкновений. В некоторых играх наложения могут блокироваться.", 14, 0xFFB8C5D7, false);
        help.setPadding(0, dp(24), 0, dp(14)); root.addView(help);
        setContentView(scroll);
    }
    @Override protected void onResume() {
        super.onResume();
        if (permissionStatus != null) permissionStatus.setText(Settings.canDrawOverlays(this) ? "✓ Разрешение на наложение выдано" : "! Требуется разрешение на наложение");
    }
    private void addCheck(LinearLayout box, String label, String key, boolean def) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label); cb.setTextColor(0xFFE7EAF2); cb.setTextSize(15);
        cb.setPadding(0, dp(7), 0, dp(7));
        cb.setChecked(prefs.getBoolean(key, def));
        cb.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean(key, checked).apply());
        box.addView(cb);
    }
    private void updateColorText() { colorButton.setText("Цвет линий: " + colorNames[prefs.getInt("colorIndex", 0)] + "  ↻"); }
    private TextView text(String msg, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(msg); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setLineSpacing(dp(4), 1.03f);
        return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF253344); bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52)); p.topMargin = dp(10); b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run()); return b;
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
}
