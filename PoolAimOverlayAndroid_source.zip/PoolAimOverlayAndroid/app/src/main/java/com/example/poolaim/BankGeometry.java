package com.example.poolaim;

import java.util.ArrayList;
import java.util.List;

/** Pure 2-D ray/reflection math; no Android dependency. Uses rectangular cushion boundaries. */
public final class BankGeometry {
    private BankGeometry() {}
    public static final class Segment {
        public final float x1, y1, x2, y2;
        public Segment(float x1, float y1, float x2, float y2) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
        }
    }
    /** n bounces produce n+1 ray segments, ending at the next cushion. */
    public static List<Segment> trace(float left, float top, float right, float bottom,
                                      float sx, float sy, float dx, float dy, int n) {
        List<Segment> segments = new ArrayList<>();
        double norm = Math.hypot(dx, dy);
        if (norm < 0.00001 || right <= left || bottom <= top) return segments;
        double vx = dx / norm, vy = dy / norm;
        double x = Math.max(left, Math.min(right, sx));
        double y = Math.max(top, Math.min(bottom, sy));
        for (int k = 0; k <= n; k++) {
            double tx = Double.POSITIVE_INFINITY, ty = Double.POSITIVE_INFINITY;
            if (vx > 1e-9) tx = (right - x) / vx;
            if (vx < -1e-9) tx = (left - x) / vx;
            if (vy > 1e-9) ty = (bottom - y) / vy;
            if (vy < -1e-9) ty = (top - y) / vy;
            double t = Math.min(tx, ty);
            if (!Double.isFinite(t) || t < 1e-6) break;
            double nx = Math.max(left, Math.min(right, x + t * vx));
            double ny = Math.max(top, Math.min(bottom, y + t * vy));
            segments.add(new Segment((float)x, (float)y, (float)nx, (float)ny));
            if (Math.abs(tx - ty) < 1e-6) { vx = -vx; vy = -vy; }
            else if (tx < ty) vx = -vx;
            else vy = -vy;
            x = nx; y = ny;
        }
        return segments;
    }
}
