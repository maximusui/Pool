package com.example.poolaim;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

/** Transparent manually calibrated aiming guide, intentionally without screen capture. */
public class OverlayView extends View {
    private final SharedPreferences preferences;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    // All coordinates are fractions of this view; landscape and portrait each have a layout.
    private final RectF table = new RectF();
    private final PointF a = new PointF(), b = new PointF(), guide = new PointF();
    private String keyPrefix = "";
    private boolean initialized, editing = true;
    private int active = -1; // 0=a 1=b 2=guide 3=table 10..17=grips
    private float downX, downY;
    private final RectF tableAtDown = new RectF();
    private final PointF aAtDown = new PointF(), bAtDown = new PointF(), guideAtDown = new PointF();
    private static final int[] COLORS = {Color.WHITE, 0xFF38E6B0, 0xFF00DCFF, 0xFFFFDB70, 0xFFFF63A5};

    public OverlayView(Context context, SharedPreferences preferences) {
        super(context);
        this.preferences = preferences;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setBackgroundColor(Color.TRANSPARENT);
    }

    public void setEditing(boolean editing) { this.editing = editing; invalidate(); }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;
        String key = w >= h ? "land_" : "port_";
        if (!initialized || !key.equals(keyPrefix)) {
            keyPrefix = key;
            loadPositions();
            initialized = true;
        }
    }

    private void defaults() {
        table.set(0.07f, 0.14f, 0.93f, 0.87f);
        a.set(0.29f, 0.51f);
        b.set(0.66f, 0.51f);
        guide.set(0.5f, 0.51f);
    }

    private float[] parse(String s, int count) {
        if (s == null) return null;
        try {
            String[] parts = s.split(",");
            if (parts.length != count) return null;
            float[] values = new float[count];
            for (int i = 0; i < count; i++) values[i] = Float.parseFloat(parts[i]);
            return values;
        } catch (NumberFormatException e) { return null; }
    }
    private void loadPositions() {
        defaults();
        float[] t = parse(preferences.getString(keyPrefix + "table", null), 4);
        float[] pa = parse(preferences.getString(keyPrefix + "ballA", null), 2);
        float[] pb = parse(preferences.getString(keyPrefix + "ballB", null), 2);
        float[] pg = parse(preferences.getString(keyPrefix + "guide", null), 2);
        if (t != null) table.set(t[0], t[1], t[2], t[3]);
        if (pa != null) a.set(pa[0], pa[1]);
        if (pb != null) b.set(pb[0], pb[1]);
        if (pg != null) guide.set(pg[0], pg[1]);
        table.left = clamp(table.left, 0, .98f); table.top = clamp(table.top, 0, .98f);
        table.right = clamp(table.right, table.left + .02f, 1f);
        table.bottom = clamp(table.bottom, table.top + .02f, 1f);
        constrainPoints(); invalidate();
    }
    public void savePositions() {
        if (!initialized || keyPrefix.isEmpty()) return;
        preferences.edit()
                .putString(keyPrefix + "table", table.left + "," + table.top + "," + table.right + "," + table.bottom)
                .putString(keyPrefix + "ballA", a.x + "," + a.y)
                .putString(keyPrefix + "ballB", b.x + "," + b.y)
                .putString(keyPrefix + "guide", guide.x + "," + guide.y)
                .apply();
    }
    public void resetPositions() {
        preferences.edit()
                .remove("port_table").remove("port_ballA").remove("port_ballB").remove("port_guide")
                .remove("land_table").remove("land_ballA").remove("land_ballB").remove("land_guide")
                .apply();
        defaults(); invalidate(); savePositions();
    }
    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
    private void constrainPoints() {
        for (PointF p : new PointF[] {a, b, guide}) {
            p.x = clamp(p.x, table.left, table.right);
            p.y = clamp(p.y, table.top, table.bottom);
        }
    }
    private RectF screenTable() {
        return new RectF(table.left * getWidth(), table.top * getHeight(),
                table.right * getWidth(), table.bottom * getHeight());
    }
    private PointF px(PointF p) { return new PointF(p.x * getWidth(), p.y * getHeight()); }
    private PointF[] pockets(RectF r) {
        return new PointF[] {
                new PointF(r.left, r.top), new PointF(r.centerX(), r.top), new PointF(r.right, r.top),
                new PointF(r.left, r.bottom), new PointF(r.centerX(), r.bottom), new PointF(r.right, r.bottom)
        };
    }
    private int color() { return COLORS[Math.floorMod(preferences.getInt("colorIndex", 0), COLORS.length)]; }
    private float dp(float n) { return n * getResources().getDisplayMetrics().density; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!initialized || getWidth() == 0 || getHeight() == 0) return;
        final RectF r = screenTable();
        int main = color();
        float thickness = dp(preferences.getInt("thickness", 3));
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1.6f));
        paint.setColor(editing ? 0xEFFFFFFF : 0x66FFFFFF);
        canvas.drawRoundRect(r, dp(12), dp(12), paint);
        PointF[] pockets = pockets(r);
        paint.setStrokeWidth(dp(1.3f)); paint.setColor(main);
        for (PointF pocket : pockets) canvas.drawCircle(pocket.x, pocket.y, dp(9), paint);
        PointF A = px(a), B = px(b), G = px(guide);

        if (preferences.getBoolean("pockets", true)) {
            for (PointF pocket : pockets) drawGlowLine(canvas, G.x, G.y, pocket.x, pocket.y, main, thickness, 100);
        }
        float dx = B.x - A.x, dy = B.y - A.y;
        if (preferences.getBoolean("direct", true)) {
            drawGlowLine(canvas, A.x, A.y, B.x, B.y, main, thickness, 255);
        }
        boolean single = preferences.getBoolean("bank", true);
        boolean doubled = preferences.getBoolean("doublebank", true);
        if (Math.hypot(dx, dy) > dp(2) && (single || doubled)) {
            int reflections = doubled ? 2 : 1;
            List<BankGeometry.Segment> segments = BankGeometry.trace(r.left, r.top, r.right, r.bottom,
                    B.x, B.y, dx, dy, reflections);
            for (int i = 0; i < segments.size(); i++) {
                BankGeometry.Segment s = segments.get(i);
                float x2 = s.x2, y2 = s.y2;
                // A visual-only pocket snap, like the desktop source; not a physics correction.
                if (i == segments.size() - 1) {
                    for (PointF pocket : pockets) {
                        if (Math.hypot(pocket.x - x2, pocket.y - y2) < dp(12)) {
                            x2 = pocket.x; y2 = pocket.y; break;
                        }
                    }
                }
                drawGlowLine(canvas, s.x1, s.y1, x2, y2, main, thickness, 210);
            }
        }
        drawPoint(canvas, A, "A", 0xFFFFE08B, editing);
        drawPoint(canvas, B, "B", 0xFF52E5FF, editing);
        if (preferences.getBoolean("pockets", true) || editing) drawPoint(canvas, G, "●", main, editing);
        if (editing) {
            PointF[] grips = grips(r);
            paint.setStyle(Paint.Style.FILL); paint.setColor(0xEEFFFFFF);
            for (PointF g : grips) canvas.drawRoundRect(g.x - dp(5), g.y - dp(5), g.x + dp(5), g.y + dp(5), dp(2), dp(2), paint);
        }
    }
    private void drawGlowLine(Canvas c, float x1, float y1, float x2, float y2, int rgb, float width, int alpha) {
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(rgb); paint.setAlpha(Math.min(42, alpha / 5)); paint.setStrokeWidth(width + dp(8));
        c.drawLine(x1, y1, x2, y2, paint);
        paint.setColor(rgb); paint.setAlpha(alpha); paint.setStrokeWidth(width);
        c.drawLine(x1, y1, x2, y2, paint);
        paint.setAlpha(255);
    }
    private void drawPoint(Canvas c, PointF p, String label, int col, boolean edit) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(0xC8141B27);
        c.drawCircle(p.x, p.y, dp(edit ? 18 : 10), paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2.5f)); paint.setColor(col);
        c.drawCircle(p.x, p.y, dp(edit ? 17 : 10), paint);
        if (edit) {
            paint.setStyle(Paint.Style.FILL); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(dp(13));
            c.drawText(label, p.x, p.y + dp(4.5f), paint);
        }
    }
    private PointF[] grips(RectF r) {
        return new PointF[] {
                new PointF(r.left, r.top), new PointF(r.centerX(), r.top), new PointF(r.right, r.top),
                new PointF(r.left, r.centerY()), new PointF(r.right, r.centerY()),
                new PointF(r.left, r.bottom), new PointF(r.centerX(), r.bottom), new PointF(r.right, r.bottom)
        };
    }
    private boolean closeTo(float x, float y, PointF p, float radius) {
        return Math.hypot(x - p.x, y - p.y) <= radius;
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!editing || !initialized) return false;
        float x = event.getX(), y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = x; downY = y;
                tableAtDown.set(table); aAtDown.set(a); bAtDown.set(b); guideAtDown.set(guide);
                float touchR = dp(27);
                active = -1;
                if (closeTo(x, y, px(a), touchR)) active = 0;
                else if (closeTo(x, y, px(b), touchR)) active = 1;
                else if (closeTo(x, y, px(guide), touchR)) active = 2;
                else {
                    PointF[] controls = grips(screenTable());
                    for (int i = 0; i < controls.length; i++) {
                        if (closeTo(x, y, controls[i], dp(20))) { active = 10 + i; break; }
                    }
                    if (active < 0 && screenTable().contains(x, y)) active = 3;
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (active == 0 || active == 1 || active == 2) {
                    PointF p = active == 0 ? a : active == 1 ? b : guide;
                    PointF origin = active == 0 ? aAtDown : active == 1 ? bAtDown : guideAtDown;
                    p.x = clamp(origin.x + (x - downX) / getWidth(), table.left, table.right);
                    p.y = clamp(origin.y + (y - downY) / getHeight(), table.top, table.bottom);
                    if (active != 2) snapToPocket(p);
                } else if (active == 3) {
                    float ddx = (x - downX) / getWidth(), ddy = (y - downY) / getHeight();
                    ddx = clamp(ddx, -tableAtDown.left, 1 - tableAtDown.right);
                    ddy = clamp(ddy, -tableAtDown.top, 1 - tableAtDown.bottom);
                    table.set(tableAtDown); table.offset(ddx, ddy);
                    a.set(aAtDown.x + ddx, aAtDown.y + ddy);
                    b.set(bAtDown.x + ddx, bAtDown.y + ddy);
                    guide.set(guideAtDown.x + ddx, guideAtDown.y + ddy);
                } else if (active >= 10) {
                    resizeGrip(active - 10, (x - downX) / getWidth(), (y - downY) / getHeight());
                }
                invalidate(); return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                active = -1; savePositions(); invalidate(); return true;
            default: return true;
        }
    }
    private void snapToPocket(PointF p) {
        PointF[] pts = pockets(screenTable());
        for (PointF target : pts) {
            if (Math.hypot(p.x * getWidth() - target.x, p.y * getHeight() - target.y) < dp(17)) {
                p.set(target.x / getWidth(), target.y / getHeight()); break;
            }
        }
    }
    private void resizeGrip(int grip, float dx, float dy) {
        table.set(tableAtDown);
        float minW = Math.min(.9f, dp(150) / getWidth());
        float minH = Math.min(.9f, dp(90) / getHeight());
        switch (grip) {
            case 0: table.left = clamp(tableAtDown.left + dx, 0, tableAtDown.right - minW);
                    table.top = clamp(tableAtDown.top + dy, 0, tableAtDown.bottom - minH); break;
            case 1: table.top = clamp(tableAtDown.top + dy, 0, tableAtDown.bottom - minH); break;
            case 2: table.right = clamp(tableAtDown.right + dx, tableAtDown.left + minW, 1);
                    table.top = clamp(tableAtDown.top + dy, 0, tableAtDown.bottom - minH); break;
            case 3: table.left = clamp(tableAtDown.left + dx, 0, tableAtDown.right - minW); break;
            case 4: table.right = clamp(tableAtDown.right + dx, tableAtDown.left + minW, 1); break;
            case 5: table.left = clamp(tableAtDown.left + dx, 0, tableAtDown.right - minW);
                    table.bottom = clamp(tableAtDown.bottom + dy, tableAtDown.top + minH, 1); break;
            case 6: table.bottom = clamp(tableAtDown.bottom + dy, tableAtDown.top + minH, 1); break;
            case 7: table.right = clamp(tableAtDown.right + dx, tableAtDown.left + minW, 1);
                    table.bottom = clamp(tableAtDown.bottom + dy, tableAtDown.top + minH, 1); break;
        }
        a.set(aAtDown); b.set(bAtDown); guide.set(guideAtDown);
        constrainPoints();
    }
}
