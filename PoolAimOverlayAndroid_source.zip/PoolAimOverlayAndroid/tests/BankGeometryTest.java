package com.example.poolaim;

import java.util.List;

public class BankGeometryTest {
    static void near(float value, float expected) {
        if (Math.abs(value - expected) > 0.001) throw new AssertionError(value + " != " + expected);
    }
    public static void main(String[] args) {
        List<BankGeometry.Segment> horiz = BankGeometry.trace(0, 0, 1, 1, .5f, .5f, 1, 0, 2);
        if (horiz.size() != 3) throw new AssertionError("Expected 3 horizontal segments");
        near(horiz.get(0).x2, 1);
        near(horiz.get(1).x2, 0);
        near(horiz.get(2).x2, 1);

        List<BankGeometry.Segment> diag = BankGeometry.trace(0, 0, 10, 5, 2, 3, 3, -1, 1);
        if (diag.size() != 2) throw new AssertionError("Expected 2 diagonal segments");
        near(diag.get(0).x2, 10);
        near(diag.get(0).y2, 1f / 3f);
        System.out.println("All trajectory tests passed");
    }
}
